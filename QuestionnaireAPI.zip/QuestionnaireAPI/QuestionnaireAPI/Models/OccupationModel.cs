﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuestionnaireAPI.Models
{
    public class OccupationModel
    {
        public List<string> occupations { get; set; }
        public string jobTitle { get; set; }
        public string businessType { get; set; }

    }
}
