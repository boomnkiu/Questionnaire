﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuestionnaireAPI.Models
{
    public class AddressModel
    {
        public string house { get; set; }
        public string work { get; set; }
    }
}
