﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuestionnaireAPI.Models
{
    public class Personal_InfomationModel
    {
        public string title { get; set; }
        public string firstName { get; set; }
        public string LastName { get; set; }
        public DateTime birthDay { get; set; }
        public string Country { get; set; }
    }
}
