﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuestionnaireAPI.Models
{
    public class QuestionnaireModel
    {
        public Personal_InfomationModel  personal_Infomation { get; set; }
        public AddressModel address { get; set; }
        public OccupationModel occupation { get; set; }

    }
}
