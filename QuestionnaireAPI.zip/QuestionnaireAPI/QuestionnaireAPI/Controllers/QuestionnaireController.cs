﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using QuestionnaireAPI.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace QuestionnaireAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class QuestionnaireController : Controller
    {

        private readonly ILogger<QuestionnaireController> _logger;
        private IWebHostEnvironment _webHost;


        public QuestionnaireController(ILogger<QuestionnaireController> logger, IWebHostEnvironment webHost)
        {
            _webHost = webHost;
            _logger = logger;
        }

        // I using array or list because if i am frontend i will loop list Question to show Question one at time 
        // I fixed listQuestion because i don't want to use any sql database  
        // IF i have to do with db i will get data from db by using Entity Framework Core _context.TABLENAME.ToList()
        public string[] ListQuestionnaire = new string[] { "Personal Infomation", "Title: (Mr. Ms. or Mrs.)", "First name:", "Last Name:", "Date of birth:", "Country of residence:", "Address", "House", "Work", "Occupation", "Occupation", "Job Title", "Busniess Type" };

        [HttpGet("ListQuestions")]
        public ActionResult<IEnumerable<string>> GetListQuestion()
        {
            try
            {
                return Ok(ListQuestionnaire);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        // IF i have to do with db i will get data from db by using _context.MYTABLENAME.AddRange(questions)
        [HttpPost("AddQuestions")]
        public ActionResult<IEnumerable<string>> AddListQuestion(string[] questions)
        {
            try
            {
                return Ok(questions);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        // IF i have to do with db i will using 
        //_context.MYTABLENAME.Attach(questions);
        // _context.Entry(questions).State = EntityState.Modified;
        [HttpPost("UpdateQuestions")]
        public IActionResult UpdateListQuestion(string[] questions)
        {
            try
            {
                return Ok(questions);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        // IF i have to do with db i will using 
        //_context.MYTABLENAME.Remove(models);
        // or _context.MYTABLENAME.RemoveRange(models);
        [HttpPost("DeleteQuestions")]
        public IActionResult DeleteQuestion(string[] questions)
        {
            try
            {
                return Ok(questions);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        // i will validate data of Country is in notAllowCountry i will throw Exception and Tell "Cannot Select Not Allow Country"
        // IF i have to do with db i will using 
        // IF i have to do with db i will get data from db by using  _context.MYTABLENAME.AddRange(questions)
        // then gen Answer to excel
        [HttpPost("CreateAnswer")]
        public IActionResult Create([FromBody] QuestionnaireModel questionnaire)
        {
            try
            {
                string[] notAllowCountry = { "Cambodia", "Myanmar", "Pakistan" };

                if (notAllowCountry.Contains(questionnaire.personal_Infomation.Country))
                {
                    throw new Exception("Cannot Select Not Allow Country");
                }
                else
                {
                    string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    string fileName = "Answer.xlsx";
                    try
                    {
                        using (var workbook = new XLWorkbook())
                        {
                            IXLWorksheet worksheet =
                            workbook.Worksheets.Add("Answer");
                            for (int i = 0; i < ListQuestionnaire.Length; i++)
                            {
                                worksheet.Cell(1, i+1).Value = ListQuestionnaire[i];
                            }
                            worksheet.Cell(2, 2).Value = questionnaire.personal_Infomation.title;
                            worksheet.Cell(2, 3).Value = questionnaire.personal_Infomation.firstName;
                            worksheet.Cell(2, 4).Value = questionnaire.personal_Infomation.LastName;
                            worksheet.Cell(2, 5).Value = questionnaire.personal_Infomation.birthDay.ToString("MM/dd/yyyy hh:mm tt").ToString();
                            worksheet.Cell(2, 6).Value = questionnaire.personal_Infomation.Country;
                            worksheet.Cell(2, 8).Value = questionnaire.address.house;
                            worksheet.Cell(2, 9).Value = questionnaire.address.work;
                            worksheet.Cell(2, 11).Value = questionnaire.occupation.occupations.FirstOrDefault();
                            worksheet.Cell(2, 12).Value = questionnaire.occupation.jobTitle;
                            worksheet.Cell(2, 13).Value = questionnaire.occupation.businessType;

                            using (var stream = new MemoryStream())
                            {
                                workbook.SaveAs(stream);
                                var content = stream.ToArray();
                                return File(content, contentType, fileName);
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        return BadRequest(ex);
                    }
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }



        //[HttpGet("GetListAnswer")]
        //public IActionResult GetAll()
        //{
        //    try
        //    {
        //        //var res = _reportBusinessLogic.SearchCriteria(searchCriteria);
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex);
        //    }
        //}

        //[HttpPut("GetAnswerById")]
        //public IActionResult GetDataById(int id)
        //{
        //    try
        //    {
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex);
        //    }
        //}


        //[HttpPut("UpdateAnswer")]
        //public IActionResult Update([FromBody] QuestionnaireModel questionnaire)
        //{
        //    try
        //    {
        //        return Ok("Update Answer Success");
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex);
        //    }
        //}

        //[HttpDelete("DeleteAnswer")]
        //public IActionResult Delete(int id)
        //{
        //    try
        //    {
        //        return Ok("Delete Answer Success");
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex);
        //    }
        //}

    }
}

